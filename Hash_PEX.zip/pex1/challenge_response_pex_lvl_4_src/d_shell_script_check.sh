#!/bin/bash

echo "What's the correct passphrase?"
echo -n "Type passphrase: "
read user_passphrase
hashed_user_passphrase=$(echo $user_passphrase | sha256sum)
if [ "$hashed_user_passphrase" == "2e6ec20ab111dd0948324eef9b1825eed8e86bfcc64c288a7607ff9f03f585cf  -" ]
then
	echo "That's correct. Email ltjones@cmu.edu that passphrase to get password for the last challenge."
else
	echo "That's not correct. Goodbye."
fi
