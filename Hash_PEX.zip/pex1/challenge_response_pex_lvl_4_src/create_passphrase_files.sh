#!/bin/bash
awk -F'\t' '$1!=prev{close(out); out="d_passphrase-"$1".txt"; prev=$1} {sub(/[^\t]+\t/,""); print > out}' words_alpha_unix_subset.txt
